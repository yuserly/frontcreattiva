import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-politicas-calidad',
  templateUrl: './politicas-calidad.component.html'
})
export class PoliticasCalidadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
