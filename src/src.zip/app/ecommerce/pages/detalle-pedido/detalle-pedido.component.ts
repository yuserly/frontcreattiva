import { Component, Input, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Periodo, Carrito, TotalCarro, ProductoCarro, Productos, SistemaOperativo } from '../../../ecommerce/interfaces/ecommerce.interface';
import { CategoriasService } from '../../../ecommerce/services/categorias.service';
import { Router } from '@angular/router';
import { DominioComponent } from './../dominio/dominio.component';

@Component({
  selector: 'app-detalle-pedido',
  templateUrl: './detalle-pedido.component.html'
})
export class DetallePedidoComponent implements OnInit {

  //validación de boton continuar
  @ViewChild(DominioComponent) DominioView!: DominioComponent;
  //*************** */

  producto!:Productos;
  periodos:Periodo[] = [];
  carrito:Carrito[] = [];

  sistemaOperativo: SistemaOperativo[] = [];

   @Output() totalcarrod: EventEmitter<TotalCarro> = new EventEmitter();
   @Output() eventoMovil: EventEmitter<boolean> = new EventEmitter();
   @Output() eventoMovilComprar: EventEmitter<boolean> = new EventEmitter();

   @Input() totalcarroarray!:TotalCarro;
   @Input() aplicarCupon!:number;
   @Input() mostrarBtnFinalizarMovil!:boolean;
   @Input() mostrarBtnComprarMovil!:boolean;
   @Input() mostrarBtnContinuarMovil!:boolean;
   @Input() mostrarContinuarLink!:boolean;

  validezcupon:number = 0;
  cuponAplicado:any = '';
  

  form_cupon:FormGroup = this.fb.group({
    cupon:['',Validators.required]
  })


  constructor(private fb: FormBuilder, private CategoriasService: CategoriasService, private router: Router) { }

  ngOnInit(): void {

    if (localStorage.getItem('carrito')) {

      let index = JSON.parse(localStorage.getItem('index')!);
      let carrito: Carrito[] =  JSON.parse(localStorage.getItem('carrito')!);
      let cdescuento:number = 0;
      console.log("detalles del carrito");
      console.log(this.totalcarroarray);
      console.log("....................");
      //var cdescuento = <number>carrito[index]['cupon_descuento'];

      carrito.map((p, i) => {

        if(p['cupon_descuento'] && p['cupon_descuento']!=0){

          cdescuento = <number>p['cupon_descuento'];

        }

      });

      //console.log("cupon: "+cdescuento);

      if(cdescuento!=0){
        this.validezcupon = 1;
      }else{
        this.validezcupon = 0;
      }

    }


  }

  validarcupon(){

    if(this.form_cupon.invalid){
      this.form_cupon.markAllAsTouched()
      return;
    }

    let index = JSON.parse(localStorage.getItem('index')!);
    let carrito: Carrito[] =  JSON.parse(localStorage.getItem('carrito')!);
    const producto = carrito[index].producto;
    let productoexiste = 0; //contador de coincidencias

    const cupon = this.form_cupon.value.cupon;
    //console.log(producto.subcategoria_id);
    console.log(carrito);
    
    this.CategoriasService.validarcupon(cupon).subscribe( resp => {


      if(resp['monto']!=0){

        //validar que haya sido ingresado algún producto compatible con el cupon
        resp['subcategorias'].forEach((element:any) => {

          console.log(element);

          
          carrito.forEach((element2) => {

            if(element2.producto.subcategoria_id==element.subcategoria_id){
              productoexiste++;
            }

          });
          

        });
        //************
        
        if(productoexiste>0){

          if(resp['tipo_descuento']==1){ //monto fijo
             carrito[0].cupon_descuento = resp['monto'];
             carrito[0].code_cupon_descuento = cupon;
             
          }else if(resp['tipo_descuento']==2){ //porcentaje de descuento
            const descc = (resp['monto'] * producto.ahorro)/100;
            carrito[0].cupon_descuento = descc;
            carrito[0].code_cupon_descuento = cupon;
          }

          localStorage.setItem('carrito',JSON.stringify(carrito));

          this.validezcupon = 1;
          this.cuponAplicado = cupon;

        }else{

          this.validezcupon = 2;

        }


      }else{

        this.validezcupon = 2;

      }

      let productoscarro = this.CategoriasService.calculototalcarro();
      this.totalcarrod.emit(productoscarro);

    });

  }

  quitarCupon(){

    this.form_cupon.patchValue({
        cupon: ''
    });

    let index = JSON.parse(localStorage.getItem('index')!);
    let carrito: Carrito[] =  JSON.parse(localStorage.getItem('carrito')!);
    carrito[index].cupon_descuento = 0;
    carrito[index].cupon_descuento = 0;
    localStorage.setItem('carrito',JSON.stringify(carrito));
    this.validezcupon = 0;

    let productoscarro = this.CategoriasService.calculototalcarro();
    this.totalcarrod.emit(productoscarro);
  }

  finalizarcompras(){

    this.router.navigate(['/login-rapido']);

  }

  continuar(){

    this.eventoMovil.emit(true);

  }

  finalizarcomprar(){

    this.eventoMovilComprar.emit(true);

  }


}
