import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formas-pago',
  templateUrl: './formas-pago.component.html'
})
export class FormasPagoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
