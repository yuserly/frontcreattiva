export const environment = {
  production: false,
  //urlBase: 'https://admin.v2.creattiva.cl/api',
  urlBase: 'https://creattiva-api.cl/api',
};
